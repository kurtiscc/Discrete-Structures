#include <iostream>
#include <string>
#include <queue>

class Rule
{

public:
	Rule(){};
	virtual ~Rule(){}
};