#pragma once
#include <string>

using namespace std;

class parameter
{
public:
	parameter(){}
	void setSorI(string t);
	string getSorI();

private:
	string SorI;



};
