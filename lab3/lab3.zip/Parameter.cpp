#include "Parameter.h"

void parameter::setSorI(string t)
{
	SorI=t;
}
string parameter::getSorI()
{
	return SorI;
}