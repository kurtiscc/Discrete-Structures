#include "DB.h"

void database::add(Relation r)
{
	DB_vec.push_back(r);
}